<?php

require __DIR__ . '/vendor/autoload.php';

use Firebase\JWT\JWT;
use Firebase\JWT\Key;

require "token_jwt.php";

session_start();

if (!isset($_SESSION["access_token"])){
    header("Location: login.php");
    exit;
}

$access_token = $_SESSION["access_token"];

try{

    $decode = JWT::decode($access_token,  new Key('SECRET_KEY_SECRET_KEY_SECRET_KEY', 'HS256') );

    $userId = $decode->sub;

    $tokenData = generate_token($userId);
    insert_token($db, $userId, $tokenData["access_token"], $tokenData["expire"]);
    $_SESSION["access_token"] = $tokenData["access_token"];


} catch (Exception $e){
    session_destroy();

    header("Location: login.php");
    exit;
}

?>