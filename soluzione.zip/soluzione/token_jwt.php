<?php

require __DIR__ . '/vendor/autoload.php';

use Firebase\JWT\JWT;
use Firebase\JWT\Key;

require "db.php";


function generate_token($userId) {

    $now = time();
    $expire = $now + (10 * 60);

    $payload = [
        'iat' => $now,
        'exp' => $expire,
        'sub' => $userId
    ];

    $accessToken = JWT::encode($payload, "SECRET_KEY_SECRET_KEY_SECRET_KEY", "HS256");

    return [
        "access_token" => $accessToken,
        "expire" => $expire
    ];
}

function insert_token($db, $userId, $accessToken, $expire){
    $expire_datetime = date('Y-m-d H:i:s', $expire);

    $stmt = $db->prepare(
        "INSERT INTO user_tokens (user_id, token, expires_at) VALUES (?, ?, ?)"
    );
    $stmt->bind_param("iss", $userId, $accessToken, $expire_datetime);
    $stmt->execute();

    return 1;
}


?>