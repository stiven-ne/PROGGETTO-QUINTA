<?php

require "token_jwt.php";

$error = "";

if($_SERVER["REQUEST_METHOD"] === 'POST') {

    $email = $_POST["email"] ?? "";
    $password = $_POST["password"] ?? "";

    $stmt = $db->prepare("
        SELECT id, password_hash FROM users WHERE email = ?
    ");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 0){
        $error = "Email sbagliata";
    } else {
        $row = $result->fetch_assoc();

        // TODO: calcola hash

        if ($row["password_hash"] == $password) {

            $tokenData = generate_token($row["id"]);
            insert_token($db, $row["id"], $tokenData["access_token"], $tokenData["expire"]);

            session_start();
            $_SESSION["access_token"] = $tokenData["access_token"];

            header("Location: dashbord.php");
            
        } else {
            $error = "Password sbagliata";
            //$error = "Email o Password sbagliata"
        }
    }
}

?>

<html>
    <body>
        <h1>Login</h1>
        <form method="POST" >
            <?php
                if ($error) {
                    echo "<div style=\"color: red;\">".$error."</div>";
                }
            ?>
            <input type="email" name="email" required/>
            <input type="password" name="password" required/>
            <button type="submit">Login</button>
        </form>
    </body>
</html>