<?php
function db_connect(){
	$db = new mysqli("localhost", "root", "", "gestione_finanze");
    return $db;
}

$db = db_connect()
?>