<?php

$stmt = $db->prepare("
    SELECT u.email, r.name, p.id, p.code, p.description
    FROM users u
    JOIN user_roles ur ON u.id = ur.user_id
    JOIN roles r ON ur.role_id = r.id
    JOIN role_privileges rp ON r.id = rp.role_id
    JOIN privileges p ON rp.privilege_id = p.id
    WHERE u.id = ?
");
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();

$privileges = array();
while($row = $result->fetch_assoc()){
    $privileges[] = $row;
}


function hasPrivileges($priv, $privileges){
    return in_array($priv, $privileges);
}

/* CRUD PRIVILEGES */

function read_privileges($db){
    if(!hasPrivileges("permessi", $privileges)){
        return -1;
    }

    $stmt = $db->query("
        SELECT u.email, r.name, p.id, p.code, p.description
        FROM users u
        JOIN user_roles ur ON u.id = ur.user_id
        JOIN roles r ON ur.role_id = r.id
        JOIN role_privileges rp ON r.id = rp.role_id
        JOIN privileges p ON rp.privilege_id = p.id
    ");
    $result = $stmt->get_result();

    $privileges = array();
    while($row = $result->fetch_assoc()){
        $privileges[] = $row;
    }

    return $privileges;
}

function create_privileges($db, $idRole, $idPrivileg){
    if(!hasPrivileges("permessi", $privileges)){
        return -1;
    }

    $stmt = $db->prepare("
        INSERT INTO role_privileges (role_id, privilege_id) VALUES (?, ?)
    ");
    $stmt->bind_param("ii", $idRole, $idPrivileg);
    $stmt->execute();

    return 1;
}

function delete_privileges($db, $idRole, $idPrivileg){
    if(!hasPrivileges("permessi", $privileges)){
        return -1;
    }

    $stmt = $db->prepare("
        DELETE role_privileges WHERE role_id = ? AND privilege_id = ?
    ");
    $stmt->bind_param("ii", $idRole, $idPrivileg);
    $stmt->execute();

    return 1;
}

?>