<?php

require "token_check.php";

require "privileges.php";

$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST"){
    $id_role = $_POST["id_role"] ?? "";
    $id_priv = $_POST["id_priv"] ?? "";


    if (isset($_POST["create"])) {
        $ret = create_privileges($db, $id_role, $id_priv);

        if ($ret === -1){
            $error = "Non hai i privilegi";
        }
    }

    if (isset($_POST["delete"])) {
        $ret = delete_privileges($db, $id_role, $id_priv);

        if ($ret === -1){
            $error = "Non hai i privilegi";
        }
    }

    $privileges = read_privileges($db);
}

?>

<html>
    <body>
        <?php foreach($privileges as $priv): ?>
            <div style="border-bottom: 1px solid black">
                <p>Email: <?= $priv["email"] ?></p>
                <p>Role: <?= $priv["name"] ?></p>
                <p>Privilege Id: <?= $priv["id"] ?></p>
                <p>Privilege Code: <?= $priv["code"] ?></p>
                <p>Privilege description: <?= $priv["description"] ?></p>
            </div>
        <?php endforeach; ?>
        
        <form method="POST" style="margin-top: 12px">
            <?php if ($error): ?>
                <div style="color: red;"><?= $error ?></div>
            <?php endif; ?>

            <input type="text" name="id_role" required/>
            <input type="text" name="id_priv" required/>

            <button type="submit" name="create">Create</button>
            <button type="submit" name="delete">Delete</button>
        </form>


    </body>
</html>