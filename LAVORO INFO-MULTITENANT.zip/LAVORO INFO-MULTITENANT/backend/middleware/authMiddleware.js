const jwt = require('jsonwebtoken');

exports.protect = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ message: "Non autorizzato" });

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    
    // IMPORTANTE: Ora decoded contiene { id, tenant_id, role }
    req.user = decoded; 
    
    next();
  } catch (err) {
    res.status(401).json({ message: "Token scaduto o non valido" });
  }
};

exports.isAdmin = (req, res, next) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ message: "Accesso negato: serve ruolo Admin" });
  }
  next();
};